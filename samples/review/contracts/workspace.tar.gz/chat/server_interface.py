from abc import ABC, abstractmethod
import socket

class ChatServerInterface(ABC):
    """Interface for a multi-client TCP chat server."""

    @abstractmethod
    def start(self) -> int:
        """Bind, listen and start accepting clients. Returns the listening port."""
        ...

    @abstractmethod
    def stop(self) -> None:
        """Stop the server and close all client connections."""
        ...

    @abstractmethod
    def client_count(self) -> int:
        """Return the number of currently connected clients."""
        ...

    @abstractmethod
    def broadcast(self, message: str, sender: socket.socket | None = None) -> None:
        """Send a message to all connected clients except the optional sender."""
        ...
