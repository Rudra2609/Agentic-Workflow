from abc import ABC, abstractmethod

class ChatClientInterface(ABC):
    """Interface for a TCP chat client."""

    @abstractmethod
    def send(self, message: str) -> None:
        """Send a message to the server."""
        ...

    @abstractmethod
    def receive(self) -> str:
        """Receive the next complete message from the server (blocking)."""
        ...

    @abstractmethod
    def close(self) -> None:
        """Close the connection to the server."""
        ...
